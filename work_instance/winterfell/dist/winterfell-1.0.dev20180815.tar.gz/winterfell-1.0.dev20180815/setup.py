import setuptools

try:
    import multiprocessing
except ImportError:
    pass

setuptools.setup(
    name='winterfell',
    version='1.0',
    packages=['winterfell'],
)
